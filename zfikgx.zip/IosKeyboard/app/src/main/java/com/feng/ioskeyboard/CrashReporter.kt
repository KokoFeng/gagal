package com.feng.ioskeyboard

import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Mencatat penyebab crash ke file lokal, lalu menampilkannya saat aplikasi dibuka lagi
 * supaya pengguna bisa menyalin/membagikan laporan itu ke developer.
 */
object CrashReporter {
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")

    fun install(app: Application) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
                val info = "KeyOS crash report\n" +
                    "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                    "${Build.MANUFACTURER} ${Build.MODEL}\n" +
                    "ABI: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
                    "Thread: ${t.name}\n\n$sw"
                file(app).writeText(info)
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    fun pending(c: Context): String? = try { file(c).takeIf { it.exists() }?.readText() } catch (_: Throwable) { null }

    fun clear(c: Context) { try { file(c).delete() } catch (_: Throwable) {} }

    /** Bila ada laporan crash sebelumnya, tampilkan dialog dengan tombol Salin / Bagikan. */
    fun showIfAny(act: Activity) {
        val report = pending(act) ?: return
        try {
            AlertDialog.Builder(act)
                .setTitle(Lang.tr("Laporan error"))
                .setMessage(Lang.tr("KeyOS berhenti pada pemakaian terakhir. Kirim laporan ini ke developer agar bisa diperbaiki.") + "\n\n" + report.take(1400))
                .setPositiveButton(Lang.tr("Bagikan")) { _, _ ->
                    try {
                        act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report), Lang.tr("Bagikan")))
                    } catch (_: Throwable) {}
                    clear(act)
                }
                .setNeutralButton(Lang.tr("Salin")) { _, _ ->
                    try {
                        (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("KeyOS crash", report))
                        Toast.makeText(act, Lang.tr("Laporan disalin"), Toast.LENGTH_SHORT).show()
                    } catch (_: Throwable) {}
                    clear(act)
                }
                .setNegativeButton(Lang.tr("Tutup")) { _, _ -> clear(act) }
                .setCancelable(false)
                .show()
        } catch (_: Throwable) {}
    }
}
